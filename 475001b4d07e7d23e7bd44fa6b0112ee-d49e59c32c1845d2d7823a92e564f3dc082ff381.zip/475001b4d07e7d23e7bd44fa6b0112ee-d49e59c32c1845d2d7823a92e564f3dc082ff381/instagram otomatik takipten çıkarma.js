// GOOGLE CHROME'DA NASIL ÇALIŞTIRILIR
// 1. INSTAGRAM'I AÇIN
// 2. TAKİPÇİ LİSTESİNİ AÇIN
// 3. GELİŞTİRİCİ ARAÇLARINI AÇIN (F12)
// 4. HER ŞEYİ KOPYALA (CTRL + A)
// 5. "KONSOLA" HER ŞEYİ YAPIŞTIR
// 6. ENTER TIKLAYIN
// ARTIK HİÇ BİR ARKADAŞLARIN OLMAYACAK :D

const TAKIPTESIN_BUTONU = 'Takiptesin' // BUNU DİLİNİZE GÖRE DEĞİŞTİRİN
const TAKIBI_BIRAK_BUTONU = 'Takibi Bırak'// BU DA
const TAKIBI_BIRAK_DENEMELERI = 3 // PATATES PC'NİZ VARSA BUNU DÜŞÜRÜN

const birinitakiptencikar = () => {
    const followingButton = document
        .evaluate(`//button[text()="${TAKIPTESIN_BUTONU}"]`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null)
        .singleNodeValue
    if (followingButton) {
        console.log('Takibi Bırak butonu bulundu. Tıklanılıyor...')
        followingButton.click()
        console.log('Takibi Bırak Butonu Tıklanıldı')
        let takibibirakbutonu = document.evaluate(`//button[text()="${TAKIBI_BIRAK_BUTONU}"]`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue
        let denemeler = 1
        while (denemeler < TAKIBI_BIRAK_DENEMELERI && !takibibirakbutonu) {
            console.log(`Takibi Bırak butonu bulmaya çalıştı ama başaramadı. Yeniden dene #${denemeler++}`)
            takibibirakbutonu = document.evaluate(`//button[text()="${TAKIBI_BIRAK_BUTONU}"]`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue
        }
        if (denemeler < TAKIBI_BIRAK_DENEMELERI) {
            console.log('Takip etmeyi bırak düğmesi bulundu. Kaydırılıyor ve tıklanılıyor ...')
            takibibirakbutonu.scrollIntoView(true)
            takibibirakbutonu.click()
        } else {
            console.log(`Yeniden denendi ${TAKIBI_BIRAK_DENEMELERI} ve başarılı olamadı`)
        }
        return false
    }
    return true
}

const bitmesuresi = (ms) => new Promise(resolve => setTimeout(resolve, ms))

const otomatikzamanlama = () => (Math.floor((Math.random() * 30) + 35) * 40) + 45

const herkesitakiptencikar = async () => {
    let duracak = false
    while (!duracak) {
        duracak = birinitakiptencikar()
        const takipcikarmasuresi = otomatikzamanlama()
        console.log(`bekleniliyor ${takipcikarmasuresi} saniye. Durmalı: ${duracak}.`)
        await bitmesuresi(takipcikarmasuresi)
    }
    console.log('Artık Hiç Arkadaşın Kalmadı XD Artık bir YIKIKSIN')
}

herkesitakiptencikar()